abstract class DashBoardDataController {
  String? name;
}
