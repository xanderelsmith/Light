enum PatientCase {
  minor,
  major,
  severe,
}

enum Payment { nill, incomplete, complete }
