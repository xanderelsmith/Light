class ParseKeys {
  static const kappId = 'RphzqBv6ywUZewBDGdUrZv7mPrpGEUwGw9PSoWBb';
  static const kclientKey = 'FofuQKqrOFpIO2TbOvisoBO9qTlirNCMvkaLLXzV';
  static const keyParseServerUrl = 'https://parseapi.back4app.com';
}
