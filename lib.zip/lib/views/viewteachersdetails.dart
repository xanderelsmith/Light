import 'package:flutter/material.dart';

class ViewTeachersScreen extends StatelessWidget {
  const ViewTeachersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
